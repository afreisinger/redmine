function remove_invoice_fields (link) {
  $(link).prev("input[type=hidden]").val("1");
  $(link).parents('.fields').hide();
  updateInvoiceTotal();
  reorderLines();
}

function add_invoice_fields (link, association, content) {
  var new_id = new Date().getTime();
  var regexp = new RegExp("new_" + association, "g");
  var regexp = new RegExp("new_" + association, "g");
  $('#sortable tr').last().after(content.replace(regexp, new_id));
  updateInvoiceTotal();
  $('#sortable tr td.price').last().mouseenter( invoiceMenuShow ).mouseleave( invoiceMenuHide );
  $('#invoice_lines_attributes_' + new_id + '_description').focus();
  reorderLines();
}

function formatCurrency(num) {
    num = isNaN(num) || num === '' || num === null ? 0.00 : num;
    return parseFloat(num).toFixed(2);
}

function updateTotal(element) {
  row = $(element).parents('tr');
  amount_value = row.find('.price input').val() * row.find('.quantity input').val();
  row.find('.total').html(formatCurrency(amount_value));
  return false;
}

function activateTextAreaResize(element) {
  $(element).keyup(function() {
    while($(element).outerHeight() < element.scrollHeight + parseFloat($(element).css("borderTopWidth")) + parseFloat($(element).css("borderBottomWidth")) && $(element).outerHeight() < 300) {
          $(element).height($(element).height()+15);
    };
  });

}

function reorderLines() {
  $('tr.sortable-line:visible').each(function(i, elem){
    $(elem).find('input.position').val(i + 1);
  });
}

function updateInvoiceTotal(element) {
  const rows = $(".invoice-lines tr.line.fields:visible"); // All visible table rows
  let amountTotal = 0; // Total amount without tax
  let taxTotal = 0;    // Total tax amount
  let grandTotal = 0;  // Total amount including tax

  rows.each(function() {
    const $row = $(this);
    const quantity = parseFloat($row.find("td.quantity input").val()) || 0;
    const price = parseFloat($row.find("td.price input").val()) || 0;
    const taxRate = parseFloat($row.find("td.tax input[type='text']").val()) || 0;

    const amount = Math.round((price * quantity) * 100) / 100; // Round to 2 decimal places
    const tax = Math.round((amount * taxRate) / 100 * 100) / 100; // Round to 2 decimal places
    const subtotal = Math.round((amount + tax) * 100) / 100; // Round to 2 decimal places

    $row.find("td.total").html(amount.toFixed(2));

    amountTotal += amount;
    taxTotal += tax;
    grandTotal += subtotal;
  });

  $('#total_amount').html(amountTotal.toFixed(2));
  $('#total_tax').html(taxTotal.toFixed(2));
  $('#grand_total').html(grandTotal.toFixed(2));
}

function invoiceMenuHide() {
  $('.invoice-menu').hide();
}

function invoiceMenuShow() {
  $(this).parent().find('.invoice-menu').css('display', 'inline-block')
}

function copyPriceToAll(element){
  $('td.price input').val($(element).closest('td.price').find('input').val());
  updateInvoiceTotal();
  return false;
}

$(function() {
  if ($('.invoice-lines').length)
  {

    var fixHelper = function(e, ui) {
      ui.children().each(function() {
        $(this).width($(this).width());
      });
      return ui;
    };

    $('.invoice-lines tbody#sortable').sortable({
      axis: 'y',
      opacity: 0.7,
      helper: fixHelper,
      stop: function(e,ui){reorderLines()}
    });

  }
});

function addInvoiceTemplatesCheckboxesListener() {
  $(document).ready(function() {
    $('#invoice-templates input[type=checkbox]').on('change', function () { extraLinksToggle() });
  });
};

function extraLinksToggle() {
  if ($('#invoice-templates input[type=checkbox]:checked').length > 0) {
    $('form p.other-formats').show();
  } else {
    $('form p.other-formats').hide();
  }
};

function showInvoicePayments(tab, url) {
  $("div#tab-content-payments").show();
  $('#tab-content-payments').parent().children('div.tabs').find('a').removeClass('selected');
  $('#tab-' + tab).addClass('selected');

  $("div#tab-content-comments").hide();
  replaceInHistory(url)
  return false;
};

function showInvoiceComments(tab, url) {
  $("div#tab-content-comments").show();
  $('#tab-content-comments').parent().children('div.tabs').find('a').removeClass('selected');
  $('#tab-' + tab).addClass('selected');

  $("div#tab-content-payments").hide();
  replaceInHistory(url)
  return false;
};

function showTax(element, defaultTax) {
  $(element).hide();
  $(element).parent().find('.tax-fields').show();
  $(element).next().find('input').focus();
  $(element).next().find('input').val(defaultTax);

  return false;
}
