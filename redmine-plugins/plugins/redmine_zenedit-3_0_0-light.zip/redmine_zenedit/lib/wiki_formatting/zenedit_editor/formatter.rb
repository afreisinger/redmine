# This file is a part of Redmine ZenEdit (redmine_zenedit) plugin,
# editing enhancement plugin for Redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_zenedit is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_zenedit is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_zenedit.  If not, see <http://www.gnu.org/licenses/>.

module WikiFormatting
  module ZeneditEditor
    class Formatter
      def initialize(text, options={})
        @text = text
        @options = options
      end

      def to_html(*args)
        Redmine::WikiFormatting::CommonMark::MarkdownFilter.new(@text, Redmine::WikiFormatting::CommonMark::PIPELINE_CONFIG).call
      end
    end
  end
end
