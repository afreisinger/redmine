# This file is a part of Redmine ZenEdit (redmine_zenedit) plugin,
# editing enhancement plugin for Redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_zenedit is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_zenedit is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_zenedit.  If not, see <http://www.gnu.org/licenses/>.

module WikiFormatting
  module ZeneditEditor
    module Helper
      def wikitoolbar_for(field_id, preview_url = preview_text_path)
        heads_for_wiki_formatter

        javascript_tag(
          "var zeneditEditor = new ZeneditWysiwyg(document.getElementById('#{field_id}'));"
        )
      end

      def initial_page_content(page)
        "# #{page.pretty_title}"
      end

      def heads_for_wiki_formatter
        unless @heads_for_wiki_formatter_included
          content_for :header_tags do
            javascript_include_tag(:zenedit_editor, plugin: 'redmine_zenedit')
          end
          @heads_for_wiki_formatter_included = true
        end
      end
    end
  end
end
