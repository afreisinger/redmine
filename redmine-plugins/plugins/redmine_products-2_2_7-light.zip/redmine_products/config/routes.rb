# This file is a part of Redmine Products (redmine_products) plugin,
# customer relationship management plugin for Redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_products is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_products is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_products.  If not, see <http://www.gnu.org/licenses/>.

# Plugin's routes
# See: http://guides.rubyonrails.org/routing.html

get '/projects/:project_id/orders/charts', :to => "orders_charts#show", :as => "project_orders_charts"
get '/orders/charts/', :to => "orders_charts#show", :as => "orders_charts"
get '/orders/charts/render_chart', :to => "orders_charts#render_chart"

resources :products do
  collection do
    get :bulk_edit
    get :context_menu
    post :bulk_edit
    post :bulk_update
    post :add
    delete :bulk_destroy
  end
end

resources :orders do
  collection do
    get :bulk_edit
    get :context_menu
    post :bulk_edit
    post :bulk_update
    delete :bulk_destroy
  end
end

resources :order_comments, :only => [:create, :destroy]

resources :projects do
  resources :products, :only => [:index, :new, :create]
  resources :orders, :only => [:index, :new, :create, :show]

  resources :product_subscriptions
end

resources :order_statuses, :except => :show

resources :product_categories

match 'invoices/add_product_line' => 'invoices#add_product_line', :via => :post, :as => 'add_invoice_product_line'
match 'auto_completes/products' => 'auto_completes#products', :via => :get, :as => 'auto_complete_products'
match 'auto_completes/orders' => 'auto_completes#orders', :via => :get, :as => 'auto_complete_orders'
