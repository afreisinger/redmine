# This file is a part of Redmine Products (redmine_products) plugin,
# customer relationship management plugin for Redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_products is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_products is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_products.  If not, see <http://www.gnu.org/licenses/>.

module RedmineProducts
  module Charts
    class ProductLinesSales < IntervalChart
      def initialize(query)
        super(query)
        @query = query
      end

      def chart_data
        {
          type: 'bar',
          title: l(:label_products_product_lines_sales),
          y_title: l(:label_products_sales),
          labels: labels,
          datasets: datasets,
          currencies: currencies,
          tooltips: tooltips
        }
      end

      def datasets
        currencies.map do |currency|
          {
            label: currency,
            data: dataset(currency),
            backgroundColor: random_color,
            borderColor: 'rgba(102,102,102, 1)',
            borderWidth: 2,
            fill: true
          }
        end
      end

      private

      def dataset(currency)
        data.map { |row| row["#{currency}_lines_sales"].to_f }
      end

      def fill(data)
        product_lines = get_filtered_product_lines

        product_lines.each do |line|
          order_date = line.container.order_date
          interval = data.index { |row| row['interval'] == DateUtils.start_of(@interval_size, order_date.localtime) }

          next unless interval

          line_total = line.total.to_f

          order_params = {
            "#{line.container.currency}_lines_sales" => line_total
          }
          data[interval].merge!(order_params) { |_, old, new| old.to_f + new }
        end
        data
      end

      def get_filtered_product_lines
        lines_scope = ProductLine.where(container_type: 'Order')
          .joins('INNER JOIN orders ON product_lines.container_id = orders.id')
          .joins('INNER JOIN projects ON orders.project_id = projects.id')
          .includes([:container])
          .where(Project.allowed_to_condition(User.current, :view_orders))

        if @statement.present?
          lines_scope = lines_scope.where(@statement.gsub('orders.', 'orders.'))
        end

        if @query.filters['products'].present? && @query.filters['products'][:values].present?
          product_ids = @query.filters['products'][:values].reject(&:blank?)
          if product_ids.any?
            lines_scope = lines_scope.where(product_id: product_ids)
          end
        end

        if @query.filters['product_category_id'].present? && @query.filters['product_category_id'][:values].present?
          category_ids = @query.filters['product_category_id'][:values].reject(&:blank?)
          if category_ids.any?
            all_category_ids = category_ids.dup
            ProductCategory.where(id: category_ids).each do |category|
              all_category_ids += category.descendants.pluck(:id).map(&:to_s)
            end

            lines_scope = lines_scope.joins(:product).where(products: { category_id: all_category_ids })
          end
        end

        lines_scope.includes(:product)
      end
    end
  end
end
