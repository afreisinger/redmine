namespace :redmine do
  namespace :products do

    desc <<-END_DESC
Convert linked products for product custom field

  rake redmine:products:convert_links_to_custom_fields RAILS_ENV="production"
END_DESC

    task :convert_links_to_custom_fields => :environment do
      class ProductsIssue < ApplicationRecord; end

      products_cf = CustomField.where(type: 'IssueCustomField', field_format: 'product', name: 'Related products (converted)')
                               .first_or_initialize
      products_cf.safe_attributes = { is_for_all: true, multiple: true }

      products_cf.tracker_ids = Tracker.pluck(:id)
      products_cf.save!

      ProductsIssue.find_each do |pi|
        products_cf.custom_values.create(customized_type: Issue,
                                         customized_id: pi.issue_id,
                                         value: pi.product_id)
      end
    end
  end
end
