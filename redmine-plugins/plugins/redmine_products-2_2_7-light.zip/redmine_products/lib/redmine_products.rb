# This file is a part of Redmine Products (redmine_products) plugin,
# customer relationship management plugin for Redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_products is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_products is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_products.  If not, see <http://www.gnu.org/licenses/>.

module ProductsSettings
  def self.invoices_plugin_installed?
    @@invoices_plugin_installed ||= (Redmine::Plugin.installed?(:redmine_contacts_invoices) && Redmine::Plugin.find(:redmine_contacts_invoices).version >= "2.2.3" )
  end

  def self.products_show_in_top_menu?
    !!Setting.plugin_redmine_products["products_show_in_top_menu"]
  end

  def self.cross_project_contacts?
    !!Setting.plugin_redmine_products["cross_project_contacts"]
  end

  def self.select_companies
    Setting.plugin_redmine_products["select_companies"].to_i > 0
  end

  def self.orders_show_in_top_menu?
    !!Setting.plugin_redmine_products["orders_show_in_top_menu"]
  end

  def self.products_show_in_app_menu?
    !!Setting.plugin_redmine_products["products_show_in_app_menu"]
  end

  def self.orders_show_in_app_menu?
    !!Setting.plugin_redmine_products["orders_show_in_app_menu"]
  end

  def self.default_list_style
    'list_excerpt'
  end

  def self.invoices_fully_compatible?
    Redmine::Plugin.find(:redmine_contacts_invoices).version >= '4.1.0'
  end

  def self.product_subscriptions_show_in_top_menu?
    !!Setting.plugin_redmine_products["product_subscriptions_show_in_top_menu"]
  end
end

module RedmineProducts
end

REDMINE_PRODUCTS_REQUIRED_FILES = [
  'redmine_products/patches/add_helpers_for_products_patch',
  'redmine_products/patches/contact_patch',
  'redmine_products/patches/project_patch',
  'redmine_products/patches/contacts_helper_patch',
  'redmine_products/patches/queries_helper_patch',
  'redmine_products/patches/notifiable_patch',
  'redmine_products/patches/auto_completes_controller_patch',
  'redmine_products/patches/invoice_line_patch',
  'redmine_products/patches/invoice_line_drop_patch',
  'redmine_products/hooks/views_layouts_hook',
  'redmine_products/hooks/controller_contacts_duplicates_hook',
  'redmine_products/compatibility/application_helper_patch',
  'redmine_products/patches/my_controller_patch',
  'redmine_products/patches/query_patch',
  'redmine_products/hooks/edit_deal_line_hook',
]

REDMINE_PRODUCTS_REQUIRED_FILES << 'redmine_products/liquid/liquid' if Object.const_defined?("Liquid") rescue false

base_url = File.dirname(__FILE__)
REDMINE_PRODUCTS_REQUIRED_FILES.each { |file| require(base_url + '/' + file) }
