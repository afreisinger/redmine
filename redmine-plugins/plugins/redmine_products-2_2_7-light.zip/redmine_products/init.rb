# This file is a part of Redmine Products (redmine_products) plugin,
# customer relationship management plugin for Redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_products is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_products is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_products.  If not, see <http://www.gnu.org/licenses/>.

PRODUCTS_VERSION_NUMBER = '2.2.7'
PRODUCTS_VERSION_TYPE = "Light version"

Redmine::Plugin.register :redmine_products do
  name "Redmine Products plugin (#{PRODUCTS_VERSION_TYPE})"
  author 'RedmineUP'
  description 'Plugin for managing products and orders'
  version PRODUCTS_VERSION_NUMBER
  url 'https://www.redmineup.com/pages/plugins/products'
  author_url 'mailto:support@redmineup.com'

  requires_redmine version_or_higher: '4.0'
  begin
    requires_redmine_plugin :redmine_contacts, version_or_higher: '4.4.2'
  rescue Redmine::PluginNotFound  => e
    raise "Please install redmine_contacts plugin"
  end

  settings default: {
    orders_show_in_top_menu: true,
    products_show_in_top_menu: true,
    product_subscriptions_show_in_top_menu: true
  }, partial: 'settings/products/products'

  project_module :products do
    permission :view_products, products: [:index, :show, :context_menu, :add], read: true
    permission :add_products, products: [:new, :create]
    permission :edit_products, products: [:new, :create, :edit, :update, :bulk_update]
    permission :delete_products, products: [:destroy, :bulk_destroy]
    permission :import_products, {} if Redmine::VERSION.to_s >= '4.1'
  end

  project_module :orders do
    permission :view_orders, orders: [:show, :context_menu], read: true
    permission :view_orders_list, orders: [:index, :context_menu], read: true
    permission :add_orders, {orders: [:new, :create], products: [:add]}
    permission :edit_orders, {orders: [:new, :create, :edit, :update, :bulk_update], products: [:add]}
    permission :delete_orders, orders: [:destroy, :bulk_destroy]
    permission :comment_orders, order_comments: [:create, :destroy]
  end

  #TODO ProductSubscriptions
  project_module :product_subscriptions do
    permission :view_subscriptions, product_subscriptions: [:index, :show], read: true
    permission :add_subscriptions, {product_subscriptions: [:new, :create], products: [:add]}
    permission :edit_subscriptions, {product_subscriptions: [:new, :create, :edit, :update], products: [:add]}
    permission :delete_subscriptions, product_subscriptions: [:destroy]
  end

  Redmine::AccessControl.map do |map|
    map.project_module :issue_tracking do |map|
      map.permission :manage_product_relations, {products_issues: [:new, :add, :destroy, :autocomplete_for_product]}
    end
  end

  menu :top_menu, :product_subscriptions,
                          {controller: 'product_subscriptions', action: 'index'},
                          caption: :label_product_subscriptions_plural,
                          if: Proc.new{ User.current.allowed_to?({controller: 'product_subscriptions', action: 'index'},
                                          nil, {global: true}) && ProductsSettings.product_subscriptions_show_in_top_menu? }

  menu :top_menu, :products,
                          {controller: 'products', action: 'index', project_id: nil},
                          caption: :label_product_plural,
                          if: Proc.new{ User.current.allowed_to?({controller: 'products', action: 'index'},
                                          nil, {global: true}) && ProductsSettings.products_show_in_top_menu? }
  menu :top_menu, :orders,
                          {controller: 'orders', action: 'index', project_id: nil},
                          caption: :label_order_plural,
                          if: Proc.new{ User.current.allowed_to?({controller: 'orders', action: 'index'},
                                          nil, {global: true}) && ProductsSettings.orders_show_in_top_menu? }

  menu :application_menu, :products,
                          {controller: 'products', action: 'index', project_id: nil},
                          caption: :label_product_plural,
                          param: :project_id,
                          if: Proc.new{ User.current.allowed_to?({controller: 'products', action: 'index'},
                                          nil, {global: true})  && ProductsSettings.products_show_in_app_menu? }
  menu :application_menu, :orders,
                          {controller: 'orders', action: 'index', project_id: nil},
                          caption: :label_order_plural,
                          param: :project_id,
                          if: Proc.new{ User.current.allowed_to?({controller: 'orders', action: 'index'},
                                          nil, {global: true}) && ProductsSettings.orders_show_in_app_menu? }

  menu :project_menu, :product_subscriptions, {controller: 'product_subscriptions', action: 'index'}, caption: :label_product_subscriptions_plural, param: :project_id
  menu :project_menu, :products, {controller: 'products', action: 'index'}, caption: :label_product_plural, param: :project_id
  menu :project_menu, :orders, {controller: 'orders', action: 'index'}, caption: :label_order_plural, param: :project_id

  menu :project_menu, :new_order, {controller: 'orders', action: 'new'}, caption: :label_products_order_new, param: :project_id, parent: :new_object
  menu :project_menu, :new_product, {controller: 'products', action: 'new'}, caption: :label_products_new, param: :project_id, parent: :new_object

  menu :admin_menu, :products, {controller: 'settings', action: 'plugin', id: "redmine_products"}, caption: :label_product_plural, html: {class: 'icon'}, icon: 'package', plugin: :redmine_products

  activity_sources = {products: ['Product'], orders: ['Order'], product_subscriptions: ['ProductSubscription']}

  activity_sources.each do |event_type, class_names|
    options = { default: false, class_name: class_names }
    options[:plugin] = :redmine_products if Redmine::VERSION::MAJOR >= 6

    activity_provider event_type, **options
  end
end

if Rails.configuration.respond_to?(:autoloader) && Rails.configuration.autoloader == :zeitwerk
  Rails.autoloaders.each { |loader| loader.ignore(File.dirname(__FILE__) + '/lib') }
end

Rails.configuration.after_initialize do
  require File.dirname(__FILE__) + '/lib/redmine_products'
end
