class ActsAsTaggableMigration < ActiveRecord::Migration[4.2]
  def self.up
    ActiveRecord::Base.create_taggable_table
  end

  def self.down

  end
end