# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

class CreateUserRates < ActiveRecord::Migration[4.2]
  def up
    if table_exists?(:people_rates)
      if index_exists?(:people_rates, [:user_id, :rate_type, :from_date, :project_id],
                       name: 'index_people_rates_on_person_and_type_and_date_and_project', unique: true)
        remove_index :people_rates, name: 'index_people_rates_on_person_and_type_and_date_and_project'
      end
      rename_table :people_rates, :user_rates
      add_index :user_rates, [:user_id, :rate_type, :from_date, :project_id],
                name: 'index_user_rates_on_user_and_type_and_date_and_project', unique: true
    else
      create_table :user_rates do |t|
        t.string :rate_type, null: false
        t.float :rate
        t.datetime :from_date
        t.string :description
        t.references :project, index: true, foreign_key: true
        t.references :user, index: true, foreign_key: true

        t.timestamps null: false
      end

      add_index :user_rates, [:user_id, :rate_type, :from_date, :project_id],
                name: 'index_user_rates_on_user_and_type_and_date_and_project', unique: true
    end
  end

  def down
    drop_table :people_rates if table_exists?(:people_rates)
    drop_table :user_rates if table_exists?(:user_rates)
  end
end
