# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

class AddActivityToUserRates < ActiveRecord::Migration[4.2]
  def up
    add_column :user_rates, :activity_id, :integer, index: true
    if index_exists?(:user_rates, [:user_id, :rate_type, :from_date, :project_id],
                     name: 'index_user_rates_on_user_and_type_and_date_and_project', unique: true)
      remove_index :user_rates, name: 'index_user_rates_on_user_and_type_and_date_and_project'
      add_index :user_rates, [:user_id, :rate_type, :from_date, :project_id, :activity_id],
                name: 'index_user_rates_on_user_and_type_and_date_and_prj_and_act', unique: true
    end
  end

  def down
    if index_exists?(:user_rates, [:user_id, :rate_type, :from_date, :project_id, :activity_id],
                     name: 'index_user_rates_on_user_and_type_and_date_and_prj_and_act', unique: true)
      remove_index :user_rates, name: 'index_user_rates_on_user_and_type_and_date_and_prj_and_act'
      add_index :user_rates, [:user_id, :rate_type, :from_date, :project_id],
                name: 'index_user_rates_on_user_and_type_and_date_and_project', unique: true
    end

    remove_column :user_rates, :activity_id
  end
end
