# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

requires_redmineup version_or_higher: '1.0.10' rescue raise "\n\033[31mRedmine requires newer redmineup gem version.\nPlease update with 'bundle update redmineup'.\033[0m"

BUDGETS_VERSION_NUMBER = '1.0.8'
BUDGETS_VERSION_TYPE = "Light version"

Redmine::Plugin.register :redmine_budgets do
  name "Redmine Budgets plugin (#{BUDGETS_VERSION_TYPE})"
  author 'RedmineUP'
  description 'Budget planning and cost management for Redmine'
  version BUDGETS_VERSION_NUMBER
  url 'http://redmineup.com/pages/plugins/budgets'
  author_url 'mailto:support@redmineup.com'

  requires_redmine version_or_higher: '4.0'

  settings default: {}, partial: 'settings/budgets/index'

  project_module :budgets do
    permission :view_project_billing_details, {}
    permission :view_issue_billing_details, {}
    permission :manage_project_billing_details, { billing_details: :update_project_billing_detail }
    permission :manage_issue_billing_details, { billing_details: [:edit_issue_billing_detail, :update_issue_billing_detail] }
    permission :manage_time_entries_billing_details, { billing_details: [:bulk_update_time_entry_billing_details] }
  end
end

if (Rails.configuration.respond_to?(:autoloader) && Rails.configuration.autoloader == :zeitwerk) || Rails.version > '7.0'
  Rails.autoloaders.each { |loader| loader.ignore(File.dirname(__FILE__) + '/lib') }
end
require File.dirname(__FILE__) + '/lib/redmine_budgets'
require 'redmineup/patches/compatibility_patch'

Redmineup::Settings.initialize_gem_settings
Redmineup::Currency.add_admin_money_menu
