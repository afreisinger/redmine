# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

post '/projects/:project_id/billing-details', to: 'billing_details#update_project_billing_detail', as: 'project_billing_detail'

get '/issues/:issue_id/billing-details', to: 'billing_details#edit_issue_billing_detail', as: 'edit_issue_billing_detail'
post '/issues/:issue_id/billing-details', to: 'billing_details#update_issue_billing_detail', as: 'issue_billing_detail'

resources :user_rates, controller: 'user_rates' do
  collection do
    get :list
  end
end

resources :users do
  resources :rates, controller: 'user_rates'
end

resources :issues, :projects do
  resources :billing_details, only: [:show, :create, :update, :destroy]
end

resources :billing_details do
  collection do
    patch :bulk_update_billing_details, to: 'billing_details#bulk_update_time_entry_billing_details'
  end
end

match 'auto_completes/linked_issues' => 'auto_completes#linked_issues', :via => :get, :as => 'auto_complete_linked_issues'
match 'auto_completes/users' => 'auto_completes#users', :via => :get, :as => 'auto_complete_users'
