# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

class UserRate < ApplicationRecord
  include Redmine::SafeAttributes

  COST_RATE = 'cost_rate'.freeze
  BILL_RATE = 'bill_rate'.freeze
  RATE_TYPES = [COST_RATE, BILL_RATE]

  belongs_to :project
  belongs_to :user
  belongs_to :activity, class_name: 'TimeEntryActivity', foreign_key: :activity_id

  validates :rate_type, :rate, :from_date, presence: true
  validates :rate_type, inclusion: { in: RATE_TYPES }
  validates :rate, numericality: true
  validates :rate_type, uniqueness: { scope: [:user_id, :from_date, :project_id, :activity_id] }

  safe_attributes 'rate_type', 'rate', 'currency', 'from_date', 'project_id', 'activity_id' , 'user_id', 'description'

  scope :cost_rates, -> { where(rate_type: COST_RATE).order('from_date desc') }
  scope :bill_rates, -> { where(rate_type: BILL_RATE).order('from_date desc') }
  scope :without_user, -> { where(user_id: nil) }
  scope :without_project, -> { where(project_id: nil) }
  scope :with_project, -> { where.not(project_id: nil) }

  def self.prefix(type)
    { COST_RATE => 'cost', BILL_RATE => 'bill' }[type]
  end

  def self.current_rate(rates, date = User.current.today)
    rates.sort { |a, b| b.from_date <=> a.from_date }
      .each { |rate| return rate if rate.from_date <= date }

    nil
  end

  # Returns current rates by different projects on the date
  def self.current_rates(user_rates, date = User.current.today)
    user_rates.group_by(&:project_id).map { |_project_id, rates| current_rate(rates, date) }.compact
  end

  def self.cost_rate_for(user, date = User.current.today, project = nil)
    current_rate(user.rates.cost_rates.where(project_id: project), date).try(:rate)
  end

  def self.bill_rate_for(user, date = User.current.today, project = nil)
    current_rate(user.rates.bill_rates.where(project_id: project), date).try(:rate)
  end
end
