# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

class UserRatesQuery < Query
  self.queried_class = UserRate
  self.view_permission = :view_project_billing_details

  self.available_columns = [
    QueryColumn.new(:user, caption: :field_user),
    QueryColumn.new(:rate_type, caption: :label_budgets_billing_type),
    QueryColumn.new(:from_date, caption: :field_from_date),
    QueryColumn.new(:project, caption: :field_project),
    QueryColumn.new(:activity, caption: :field_activity),
    QueryColumn.new(:rate, caption: :field_rate),
    QueryColumn.new(:description, caption: :field_description),
  ]

  def initialize(attributes=nil, *args)
    super attributes
    self.filters ||= { 'current_rate' => { :operator => '=', :values => ['1'] }, 'with_locked' => { :operator => '=', :values => ['0'] } }
  end

  # Two methods to disable save for this type of query
  def new_record?
    false
  end

  def editable_by?(_user)
    false
  end

  def initialize_available_filters
    add_available_filter 'current_rate', type: :list, values: [[l(:general_text_yes), '1'], [l(:general_text_no), '0']], label: :label_budgets_filter_current
    add_available_filter 'with_locked', type: :list, values: [[l(:general_text_yes), '1'], [l(:general_text_no), '0']], label: :label_budgets_filter_with_locked
    add_available_filter 'project_id', type: :list, label: :field_project, values: lambda { project_values }
    add_available_filter 'rate', type: :float, label: :field_rate
    add_available_filter 'from_date', type: :date, label: :field_from_date
    add_available_filter 'rate_type', type: :list, label: :label_budgets_billing_type, values: UserRate::RATE_TYPES.map { |type| [l("label_budgets_#{type}"), type] }
    add_available_filter 'activity_id', type: :list_optional, values: -> { TimeEntryActivity.pluck(:name, :id) }, label: :field_activity
    add_available_filter 'user_id',  type: :list_optional, label: :field_user, values: -> { Principal.where(id: UserRate.pluck(:user_id).uniq).map { |user| [user.name, user.id.to_s]} }
  end

  def default_columns_names
    @default_columns_names ||= [:user, :from_date, :project, :rate_type, :activity, :rate, :description]
  end

  def object_count
    objects_scope.count
  end

  def objects_scope(options={})
    UserRate.joins('LEFT OUTER JOIN users ON users.id = user_rates.user_id').
             where(statement).
             where(options[:conditions]).
             limit(options[:limit]).
             offset(options[:offset])
             .order(user_id: :desc, from_date: :desc, project_id: :asc, activity_id: :desc)
  end

  def sql_for_current_rate_field(field, operator, value)
    subquery = UserRate.select('user_id, rate_type, MAX(from_date) AS max_from_date').where('from_date <= ?', User.current.today.tomorrow)
                       .group(:user_id, :rate_type)
    rate_ids = UserRate.joins("LEFT OUTER JOIN (#{subquery.to_sql}) latest ON user_rates.user_id = latest.user_id AND user_rates.from_date = latest.max_from_date")
                       .pluck(:id)
    op = (operator == '=' && value.first == '0') || (operator == '!' && value.first == '1') ? 'NOT IN' : 'IN'

    rate_ids.any? ? "(#{UserRate.table_name}.id #{op} (#{rate_ids.uniq.join(',')}))" : '1=1'
  end

  def sql_for_with_locked_field(field, operator, value)
    op = (operator == '=' && value.first == '0') || (operator == '!' && value.first == '1') ? '!=' : '='

    "(#{User.table_name}.status #{op} #{Principal::STATUS_LOCKED} OR users.status IS NULL)"
  end
end
