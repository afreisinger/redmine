# encoding: utf-8
#
# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class IssuesControllerTest < ActionController::TestCase
  fixtures :projects, :roles, :members, :member_roles, :users,
           :trackers, :enumerations, :issue_statuses, :enabled_modules

  create_fixtures(redmine_budgets_fixtures_directory, [:time_entries, :user_rates, :billing_details, :issues])

  def setup
    @admin = User.find(1)
    @user = User.find(2)
    @project = Project.find(1)
    @issue = Issue.find(1)
    EnabledModule.create(project: @project, name: 'budgets')
    Setting.plugin_redmine_budgets = {}
  end

  def test_should_get_show_with_billing_info
    @request.session[:user_id] = @admin.id
    compatible_request :get, :show, id: @issue.id
    assert_response :success
    assert_select '#billing-details', 1
  end

  def test_should_get_show_with_billing_info_for_regular_user
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :view_issue_billing_details
    compatible_request :get, :show, id: @issue.id
    assert_response :success
    assert_select '#billing-details', 1
  end

  def test_should_get_show_with_billing_info_and_edit_button_for_regular_user
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :view_issue_billing_details
    Role.find(1).add_permission! :manage_issue_billing_details
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
      bill_rate_type: BillingDetail::BILL_RATE_BY_ISSUE,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_FEE
    }

    compatible_request :get, :show, id: @issue.id
    assert_response :success
    assert_select 'div#billing-details div.contextual a', 'Edit'
  end

  def test_should_get_show_without_billing
    @request.session[:user_id] = @user.id
    compatible_request :get, :show, id: @issue.id
    assert_response :success
    assert_select '#billing-details', 0
  end

  def test_should_get_show_with_billing_info_by_users
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_USER
    }

    @request.session[:user_id] = @admin.id
    compatible_request :get, :show, id: @issue.id
    assert_response :success
    assert_select '#billing-details', 1
  end

  def test_should_get_show_with_billing_info_with_total_costs
    project5 = Project.find(5)
    EnabledModule.create(project: project5, name: 'budgets')
    set_billing_settings_for project5, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_USER
    }
    issue16 = Issue.find(16)
    @request.session[:user_id] = @admin.id
    compatible_request :get, :show, id: issue16.id
    assert_response :success
    assert_select '#billing-details', 1
    assert_select 'div.total-costs' do
      assert '(Total: ', 1
      assert_select 'a', 1
      assert_select 'a', { text: '$580.00' }
    end
  end
end
