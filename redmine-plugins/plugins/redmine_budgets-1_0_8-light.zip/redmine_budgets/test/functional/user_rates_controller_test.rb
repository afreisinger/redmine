# encoding: utf-8
#
# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class UserRatesControllerTest < ActionController::TestCase
  include Redmine::I18n

  fixtures :users
  create_fixtures(redmine_budgets_fixtures_directory, [:time_entries, :user_rates])

  def setup
    Setting.plugin_redmine_budgets = {}
    @admin = User.find(1)
    @user = User.find(2)
    @person = User.find(4)
    @user_rate = UserRate.find(2)
    @user_rate_params_old = { rate_type: UserRate::COST_RATE, rate: 10, from_date: '2017-02-01'.to_date, project_id: '' }
    @user_rate_params_new = { rate_type: UserRate::BILL_RATE, rate: 20.567, from_date: '2017-06-01'.to_date, project_id: '' }
    @user_rate_attributes_old = { rate_type: UserRate::COST_RATE, rate: 10, from_date: '2017-02-01'.to_date, project_id: 1 }
    @user_rate_attributes_new = { rate_type: UserRate::BILL_RATE, rate: 20.567, from_date: '2017-06-01'.to_date, project_id: nil }
  end

  def test_should_get_new_for_admin
    @request.session[:user_id] = @admin.id
    compatible_request :get, :new, user_id: @person
    assert_response :success
  end

  def test_should_not_access_new_for_anonymous
    compatible_request :get, :new, user_id: @person
    assert_response :redirect
  end

  def test_should_not_access_new_for_regular_user
    @request.session[:user_id] = @user.id
    compatible_request :get, :new, user_id: @person
    assert_response :forbidden
  end

  def test_should_access_new_with_permission_edit_rates
    @user.pref.rates_permission = RedmineBudgets::EDIT_RATES_PERMISSION
    @user.pref.save
    @request.session[:user_id] = @user.id
    request.env['HTTP_REFERER'] = '/test/0'
    compatible_request :get, :new, user_id: @person
    assert_response :success
    assert_select 'input[name="back_url"]', { count: 1 }
  end

  def test_should_create_user_rate
    @request.session[:user_id] = @admin.id
    should_create_user_rate
  end

  def test_should_not_create_user_rate
    should_not_create_user_rate
  end

  # user_id, rate_type, from_date and project_id should be unique
  def test_should_not_create_user_rate_with_the_same_params
    @request.session[:user_id] = @admin.id
    should_not_create_user_rate :success, @user_rate_params_old
    @user_rate_params_old[:rate] = 100
    should_not_create_user_rate :success, @user_rate_params_old
  end

  def test_should_create_user_rate_with_the_same_params_for_other_person
    @request.session[:user_id] = @admin.id
    should_create_user_rate @user, @user_rate_params_old
  end

  def test_should_not_access_create_without_permission_edit_rates
    @request.session[:user_id] = @user.id
    should_not_create_user_rate :forbidden
  end

  def test_should_access_create_with_permission_edit_rates
    @user.pref.rates_permission = RedmineBudgets::EDIT_RATES_PERMISSION
    @user.pref.save
    @request.session[:user_id] = @user.id
    should_create_user_rate
  end

  def test_should_get_edit
    @request.session[:user_id] = @admin.id
    request.env['HTTP_REFERER'] = '/test/0'
    compatible_request :get, :edit, id: @user_rate, user_id: @person
    assert_response :success
    assert_select 'input[name="back_url"]', { count: 1 }
  end

  def test_should_not_access_edit
    compatible_request :get, :edit, id: @user_rate, user_id: @person
    assert_response :redirect
  end

  def test_should_not_access_edit_without_permission_edit_rates
    @request.session[:user_id] = @user.id
    compatible_request :get, :edit, id: @user_rate, user_id: @person
    assert_response :forbidden
  end

  def test_should_access_edit_with_permission_edit_rates
    @user.pref.rates_permission = RedmineBudgets::EDIT_RATES_PERMISSION
    @user.pref.save
    @request.session[:user_id] = @user.id
    compatible_request :get, :edit, id: @user_rate, user_id: @person
    assert_response :success
  end

  def test_should_update_user_rate
    @request.session[:user_id] = @admin.id
    should_update_user_rate
  end

  def test_should_update_user_rate_and_redirect_to_back_url
    @request.session[:user_id] = @admin.id
    compatible_request :post, :update,
                       id: @user_rate,
                       user_id: @person,
                       user_rate: @user_rate_params_new,
                       back_url: "/users/#{@person.id}/edit?tab=rates"
    @user_rate.reload
    @user_rate_attributes_new.each { |attr, val| assert @user_rate.send(attr) == val }
    assert_redirected_to edit_user_rates_tab_path(@person)
    assert_equal "/users/#{@person.id}/edit?tab=rates", edit_user_rates_tab_path(@person)
    assert_equal flash[:notice], l(:notice_successful_update)
  end

  def test_should_not_update_user_rate
    should_not_update_user_rate
  end

  def test_should_not_access_update_without_permission_edit_rates
    @request.session[:user_id] = @user.id
    should_not_update_user_rate :forbidden
  end

  def test_should_access_update_with_permission_edit_rates
    @user.pref.rates_permission = RedmineBudgets::EDIT_RATES_PERMISSION
    @user.pref.save
    @request.session[:user_id] = @user.id
    should_update_user_rate
  end

  def test_should_destroy_user_rate
    @request.session[:user_id] = @admin.id
    assert_difference('UserRate.count', -1) do
      compatible_request :delete, :destroy, id: @user_rate, user_id: @person
    end
    assert_redirected_to edit_user_rates_tab_path(@person)
    assert_equal flash[:notice], l(:notice_user_rate_successfully_destroyed)
  end

  def test_should_not_destroy_user_rate
    assert_difference('UserRate.count', 0) do
      compatible_request :delete, :destroy, id: @user_rate, user_id: @person
    end
    assert_response :redirect
  end

  def test_should_not_access_destroy_without_permission_edit_rates
    @request.session[:user_id] = @user.id
    assert_difference('UserRate.count', 0) do
      compatible_request :delete, :destroy, id: @user_rate, user_id: @person
    end
    assert_response :forbidden
  end

  def test_should_access_destroy_with_permission_edit_rates
    @user.pref.rates_permission = RedmineBudgets::EDIT_RATES_PERMISSION
    @user.pref.save
    @request.session[:user_id] = @user.id
    assert_difference('UserRate.count', -1) do
      compatible_request :delete, :destroy, id: @user_rate, user_id: @person
    end
    assert_redirected_to edit_user_rates_tab_path(@person)
    assert_equal flash[:notice], l(:notice_user_rate_successfully_destroyed)
  end

  private

  def should_create_user_rate(person = @person, params = @user_rate_params_new)
    assert_difference('UserRate.count') do
      compatible_request :post, :create, user_id: person, user_rate: params
    end
    assert_redirected_to edit_user_rates_tab_path(person)
    assert_equal flash[:notice], l(:notice_successful_create)
  end

  def should_not_create_user_rate(response_status = :redirect, params = @user_rate_params_new)
    assert_difference('UserRate.count', 0) do
      compatible_request :post, :create, user_id: @person, user_rate: params
    end
    assert_response response_status
  end

  def should_update_user_rate
    @user_rate_attributes_old.each { |attr, val| assert @user_rate.send(attr) == val }
    compatible_request :post, :update, id: @user_rate, user_id: @person, user_rate: @user_rate_params_new
    @user_rate.reload
    @user_rate_attributes_new.each { |attr, val| assert @user_rate.send(attr) == val }
    assert_redirected_to edit_user_rates_tab_path(@person)
    assert_equal flash[:notice], l(:notice_successful_update)
  end

  def should_not_update_user_rate(response_status = :redirect)
    compatible_request :post, :update, id: @user_rate, user_id: @person, user_rate: @user_rate_params_new
    assert_response response_status
    @user_rate.reload
    @user_rate_attributes_old.each { |attr, val| assert_equal @user_rate.send(attr), val }
  end

  def edit_user_rates_tab_path(user)
    edit_user_path(user, tab: 'rates')
  end
end
