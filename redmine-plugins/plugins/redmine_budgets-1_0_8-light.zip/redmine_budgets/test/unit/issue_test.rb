# encoding: utf-8
#
# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class IssueTest < ActiveSupport::TestCase
  fixtures :projects, :roles, :members, :member_roles, :users,
           :trackers, :enumerations, :issue_statuses, :enabled_modules

  create_fixtures(redmine_budgets_fixtures_directory, [:issues, :time_entries, :user_rates, :billing_details])

  def setup
    Setting.plugin_redmine_budgets = {}
    @project = Project.find(1)
    @issue = Issue.find(1)
  end

  def test_should_allowed_to_edit_billing_type
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS
    assert @issue.allowed_to_edit?(:billing_type)

    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE
    assert @issue.allowed_to_edit?(:billing_type)
  end

  def test_should_not_allowed_to_edit_billing_type
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE
    assert !@issue.allowed_to_edit?(:billing_type)
  end

  def test_should_not_allowed_to_edit_bill_rate
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE
    assert !@issue.allowed_to_edit?(:bill_rate)

    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_USER
    }
    assert !@issue.allowed_to_edit?(:bill_rate)
  end

  def test_should_allowed_to_edit_budget
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_FEE
    }
    assert @issue.allowed_to_edit?(:budget)

    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_FEE
    }
    assert @issue.allowed_to_edit?(:budget)
  end

  def test_should_not_allowed_to_edit_budget
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }
    assert !@issue.allowed_to_edit?(:budget)

    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }
    assert !@issue.allowed_to_edit?(:budget)
  end

  def test_on_billing_type_not_billable_and_budget_type_no_budget
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: nil,

      budget: nil,
      money_budget: nil,
      spent_money: nil,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_not_billable_and_budget_type_project_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE,
      project_cost: 1000,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
      budget: 1000
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: nil,

      budget: nil,
      money_budget: nil,
      spent_money: nil,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_not_billable_and_budget_type_issues_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_TIME
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: nil,

      budget: nil,
      money_budget: nil,
      spent_money: nil,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: 200,
      spent_time: 47.5,
      spent_hours_progress: 23.75,
      remaining_hours: 152.5,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_time_and_materials_and_budget_type_no_budget_and_bill_rate_type_by_user
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_USER,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: 887.5,

      budget: nil,
      money_budget: nil,
      spent_money: 887.5,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: 355,
      profit_progress: 40
    }
  end
  def test_total_costs
    set_billing_settings_for Project.find(5), {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_USER,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_FEE,
      budget:  1000
    }
    issue = Issue.find(16)
    assert_equal 290, issue.costs
    assert_equal 580, issue.total_costs
  end
end
