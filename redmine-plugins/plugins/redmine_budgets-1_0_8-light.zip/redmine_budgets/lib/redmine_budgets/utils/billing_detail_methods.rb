# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

module RedmineBudgets
  module Utils
    module BillingDetailMethods
      def self.included(base)
        base.class_eval do
          has_one :billing_detail, as: :billable, dependent: :destroy

          scope :billable_entries, -> { joins(:billing_detail).where.not("billing_details.settings LIKE ?",
                                                                        "%:billing_type: #{BillingDetail::BILLING_TYPE_NOT_BILLABLE}%") }
        end
      end
    end
  end
end
