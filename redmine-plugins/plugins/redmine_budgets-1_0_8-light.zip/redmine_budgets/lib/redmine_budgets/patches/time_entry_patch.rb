# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

module RedmineBudgets
  module Patches
    module TimeEntryPatch
      def self.included(base)
        base.class_eval do
          extend ClassMethods
          include RedmineBudgets::Utils::BillingDetailMethods
          include InstanceMethods

          scope :not_billable, -> { billable_entries.where(project_id:  Project.billable_entries.ids) }
          scope :billable, -> { where.not(id: not_billable.ids) }

          delegate *BillingSettingsAttributes::TIME_ENTRY_SETTINGS_ATTRIBUTES, to: :billing_settings

          accepts_nested_attributes_for :billing_detail, allow_destroy: true
          safe_attributes 'billing_detail_attributes'
        end
      end

      module ClassMethods
        def default_billing_type
          new.default_billing_settings.try(:billing_type)
        end
      end

      module InstanceMethods
        def default_billing_settings
          settings = { billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS }

          BillingDetail.new(
            billable: self,
            settings: settings
          )
        end

        def billing_settings
          @billing_settings ||= billing_detail || default_billing_settings
        end

        def allowed_attribute?(attribute)
          BillingSettingsAttributes::TIME_ENTRY_SETTINGS_ATTRIBUTES.include?(attribute.to_sym)
        end

        def billable?
          project && project.billable? && billing_type != BillingDetail::BILLING_TYPE_NOT_BILLABLE
        end
      end
    end
  end
end

unless TimeEntry.included_modules.include?(RedmineBudgets::Patches::TimeEntryPatch)
  TimeEntry.send(:include, RedmineBudgets::Patches::TimeEntryPatch)
end
