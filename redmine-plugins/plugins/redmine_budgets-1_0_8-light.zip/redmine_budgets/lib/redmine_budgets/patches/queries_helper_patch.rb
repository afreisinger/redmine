# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require_dependency 'queries_helper'

module RedmineBudgets
  module Patches
    module QueriesHelperPatch
      def self.included(base)
        base.send(:include, InstanceMethods)

        base.class_eval do
          alias_method :column_value_without_budgets, :column_value
          alias_method :column_value, :column_value_with_budgets
        end
      end

      module InstanceMethods
        def column_value_with_budgets(column, item, value)
          if column.name.eql?(:from_date) && value
            format_date value
          elsif column.name.eql?(:rate_type) && value
            l("label_budgets_#{value}")
          else
            column_value_without_budgets(column, item, value)
          end
        end
      end
    end
  end
end

unless QueriesHelper.included_modules.include?(RedmineBudgets::Patches::QueriesHelperPatch)
  QueriesHelper.send(:include, RedmineBudgets::Patches::QueriesHelperPatch)
end
