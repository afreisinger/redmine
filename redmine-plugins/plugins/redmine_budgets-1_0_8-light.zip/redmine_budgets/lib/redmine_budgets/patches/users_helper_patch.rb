# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

module RedmineBudgets
  module Patches
    module UsersHelperPatch
      def self.included(base)
        base.class_eval do
          include InstanceMethods

          alias_method :user_settings_tabs_without_budgets, :user_settings_tabs
          alias_method :user_settings_tabs, :user_settings_tabs_with_budgets
        end
      end

      module InstanceMethods
        def user_settings_tabs_with_budgets
          user_settings_tabs_without_budgets << { name: 'rates', partial: 'users/rates', label: :label_budgets_rates }
        end
      end
    end
  end
end

unless UsersHelper.included_modules.include?(RedmineBudgets::Patches::UsersHelperPatch)
  UsersHelper.send(:include, RedmineBudgets::Patches::UsersHelperPatch)
end
