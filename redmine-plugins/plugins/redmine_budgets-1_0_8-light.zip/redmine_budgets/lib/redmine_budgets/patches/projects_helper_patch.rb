# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

module RedmineBudgets
  module Patches
    module ProjectsHelperPatch
      def self.included(base)
        base.class_eval do
          include InstanceMethods

          alias_method :project_settings_tabs_without_budgets, :project_settings_tabs
          alias_method :project_settings_tabs, :project_settings_tabs_with_budgets
        end
      end

      module InstanceMethods
        def project_settings_tabs_with_budgets
          tabs = project_settings_tabs_without_budgets
          if User.current.allowed_to?(:manage_project_billing_details, @project)
            tabs << {
              name: 'billing-details',
              action: :manage_project_billing_details,
              partial: 'projects/settings/billing_details',
              label: :label_budgets_billing_and_budget
            }
          end
          tabs
        end
      end
    end
  end
end

unless ProjectsHelper.included_modules.include?(RedmineBudgets::Patches::ProjectsHelperPatch)
  ProjectsHelper.send(:include, RedmineBudgets::Patches::ProjectsHelperPatch)
end
