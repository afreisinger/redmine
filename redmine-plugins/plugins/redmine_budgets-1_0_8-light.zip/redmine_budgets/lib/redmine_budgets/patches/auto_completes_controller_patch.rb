# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require_dependency 'auto_completes_controller'

module RedmineBudgets
  module Patches
    module AutoCompletesControllerPatch
      def self.included(base)
        base.send(:include, InstanceMethods)
      end

      module InstanceMethods
        DEFAULT_ISSUES_LIMIT = 30

        def linked_issues
          @linked_issues = []
          q = (params[:q] || params[:term]).to_s.strip
          scope = Issue.visible.by_project(@project)
          scope = scope.limit(params[:limit] || DEFAULT_ISSUES_LIMIT)
          scope = scope.distinct
          q.split(' ').collect { |word| scope = scope.live_search(word.gsub(/[\(\)]/, '')) } unless q.blank?
          @linked_issues = scope.to_a.sort! { |x, y| x.subject <=> y.subject }

          render layout: false, partial: 'linked_issues'
        end
      end
    end

    module AutoCompletesControllerUsersPatch
      def self.included(base)
        base.send(:include, InstanceMethods)
      end

      module InstanceMethods
        DEFAULT_USERS_LIMIT = 30

        def users
          q = (params[:q] || params[:term]).to_s.strip
          scope = User.active.where({})
          scope = scope.limit(params[:limit] || DEFAULT_USERS_LIMIT)
          scope = scope.where('LOWER(firstname) LIKE LOWER(:q) OR LOWER(lastname) LIKE LOWER(:q)', q: "%#{q}%") unless q.blank?
          scope = Rails.version >= '5.1' ? scope.distinct : scope.uniq

          render layout: false, json: format_users_json(scope.to_a)
        end

        private

        def format_users_json(users)
          users.map do |user|
            {
              id: user.id,
              text: user.to_s
            }
          end
        end
      end
    end
  end
end

if RedmineBudgets.contacts_invoices_pro_plugin_installed? &&
  AutoCompletesController.included_modules.exclude?(RedmineBudgets::Patches::AutoCompletesControllerPatch)
  AutoCompletesController.send(:include, RedmineBudgets::Patches::AutoCompletesControllerPatch)
end

unless AutoCompletesController.included_modules.include?(RedmineBudgets::Patches::AutoCompletesControllerUsersPatch)
  AutoCompletesController.send(:include, RedmineBudgets::Patches::AutoCompletesControllerUsersPatch)
end
