# encoding: utf-8
#
# This file is a part of Redmine Finance (redmine_finance) plugin,
# simple accounting plugin for Redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_finance is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_finance is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_finance.  If not, see <http://www.gnu.org/licenses/>.

# Load the Redmine helper
require File.expand_path(File.dirname(__FILE__) + '/../../../test/test_helper')
require File.expand_path(File.dirname(__FILE__) + '/../../redmine_contacts/test/test_helper')

def fixture_files_path
  "#{Rails.root}/plugins/redmine_finance/test/fixtures/files/"
end

class RedmineFinance::TestCase
  module TestHelper
    def with_finance_settings(options, &block)
      Setting.plugin_redmine_finance.stubs(:[]).returns(nil)
      options.each { |k, v| Setting.plugin_redmine_finance.stubs(:[]).with(k).returns(v) }
      yield
    end

    def operations_in_list
      ids = css_select('table.operations input').map { |tag| tag['value'].to_i }
      Operation.where(:id => ids).sort_by { |operation| ids.index(operation.id) }
    end
  end

  def self.create_fixtures(fixtures_directory, table_names, class_names = {})
    ActiveRecord::FixtureSet.create_fixtures(fixtures_directory, table_names, class_names = {})
  end
end
