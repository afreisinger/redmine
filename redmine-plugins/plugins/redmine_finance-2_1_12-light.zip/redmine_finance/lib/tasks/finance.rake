namespace :redmine do
  namespace :finance do

    desc <<-END_DESC
Create default categories.

rake redmine:finance:create_categories RAILS_ENV="production"
END_DESC

    task create_categories: :environment do
      expenses_category = OperationCategory.create(name: 'Expenses', code: '002')
      OperationCategory.create(name: 'Office expenses', parent: expenses_category)
      OperationCategory.create(name: 'Other expenses', parent: expenses_category)
      OperationCategory.create(name: 'Supplies', parent: expenses_category)

      income_category = OperationCategory.create(name: 'Income', code: '001')
      OperationCategory.create(name: 'Invoices income', parent: income_category)
      OperationCategory.create(name: 'Other income', parent: income_category)
      OperationCategory.create(name: 'Opening balance', parent: income_category)
    end
  end
end
